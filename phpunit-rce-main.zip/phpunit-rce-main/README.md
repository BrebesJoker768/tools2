# Laravel phpunit rce Auto Upload Shell

[logo]: https://raw.githubusercontent.com/MataKucing-OFC/phpunit-rce/main/lr.png "MK1337 Laravel Auto Upload Shell"	
![lr](https://user-images.githubusercontent.com/72303820/225427987-5019e48d-3c19-4d02-b752-d48281d4c766.png)

## Usage
To run this tools:
(Using python3)
```
$ pip3 install requirements.txt
$ python3 MKLaravel.py
```

## General info
This tools is exploiting phpunit rce to uploading shell or execute command from the functions. SHELL PASSWORD IS : mk1337

## Feature
This tool have some feature :
* Have 3 method exploit the phpunit
* Can recode the tool
* Can edit the exploit
* Can change the shell using your shells

## Contact me
* [Telegram](https://t.me/mk1337_HxR)
* [Facebook](https://www.facebook.com/profile.php?id=100058299691325)
